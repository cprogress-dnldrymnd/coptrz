<?php

use Carbon_Fields\Container;
use Carbon_Fields\Complex_Container;
use Carbon_Fields\Field;

class PostMeta extends GetData
{
	function _button($id, $separator = '')
	{
		$link_type = array(
			'' => 'None',
			'page_button' => 'Page',
			'post_button' => 'Post',
			'product_button' => 'Product',
			'custom_button' => 'Custom',
		);

		$buttons = array(
			Field::make('select',  $id . '_button_type',  __('Button Type'))
				->set_width(20)
				->set_options($link_type),
			Field::make('text', $id . '_button_text', 'Button Text')
				->set_help_text('Leave blank to use post title. Does not work with custom button')
				->set_width(20)
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => array('page_button', 'post_button', 'product_button', 'custom_button'),
						'compare' => 'IN'
					)
				)),
			Field::make('select',  $id . '_page_button', 'Page Link')
				->set_width(20)
				->set_options($this->get_posts('page'))
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'page_button',
					)
				)),
			Field::make('select',  $id . '_post_button', 'Post Link')
				->set_options($this->get_posts('post'))
				->set_width(20)
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'post_button',
					)
				)),
			Field::make('select',  $id . '_product_button', 'Service Link')
				->set_width(20)
				->set_options($this->get_posts('product'))
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'product_button',
					)
				)),
			Field::make('text', $id . '_custom_button', 'Custom Link')
				->set_width(20)
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'custom_button',
					)
				)),
			Field::make('select',  $id . '_button_action', 'Button Action')
				->set_options(array(
					'' => 'Same Window',
					'target="_blank"' => 'New Tab',
				))
				->set_width(20)
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => array('page_button', 'post_button', 'product_button', 'custom_button'),
						'compare' => 'IN'
					)
				)),
			Field::make('select',  $id . '_button_icon', 'Button Icon')
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => array('page_button', 'post_button', 'product_button', 'custom_button'),
						'compare' => 'IN'
					)
				))
				->set_options(svg_list())
				->set_width(20)

		);

		if ($separator) {
			return array_merge(array(
				Field::make('html', $id . '_sep')
					->set_html('<label>' . $separator . '</label>')
					->set_classes('seperator ')
			), $buttons);
		} else {
			return $buttons;
		}
	}

	function _button_full_width($id, $separator = '')
	{
		$link_type = array(
			'' => 'None',
			'page_button' => 'Page',
			'post_button' => 'Post',
			'product_button' => 'Product',
			'custom_button' => 'Custom',
		);

		$buttons = array(
			Field::make('select',  $id . '_button_type',  __('Button Type'))
				->set_options($link_type),
			Field::make('text', $id . '_button_text', 'Button Text')
				->set_help_text('Leave blank to use post title. Does not work with custom button')
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => array('page_button', 'post_button', 'product_button', 'custom_button'),
						'compare' => 'IN'
					)
				)),
			Field::make('select',  $id . '_page_button', 'Page Link')
				->set_options($this->get_posts('page'))
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'page_button',
					)
				)),
			Field::make('select',  $id . '_post_button', 'Post Link')
				->set_options($this->get_posts('post'))
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'post_button',
					)
				)),
			Field::make('select',  $id . '_product_button', 'Service Link')
				->set_options($this->get_posts('product'))
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'product_button',
					)
				)),
			Field::make('text', $id . '_custom_button', 'Custom Link')
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => 'custom_button',
					)
				)),
			Field::make('select',  $id . '_button_action', 'Button Action')
				->set_options(array(
					'' => 'Same Window',
					'target="_blank"' => 'New Tab',
				))
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => array('page_button', 'post_button', 'product_button', 'custom_button'),
						'compare' => 'IN'
					)
				)),
			Field::make('select',  $id . '_button_icon', 'Button Icon')
				->set_conditional_logic(array(
					array(
						'field' => $id . '_button_type',
						'value' => array('page_button', 'post_button', 'product_button', 'custom_button'),
						'compare' => 'IN'
					)
				))
				->set_options(svg_list())

		);

		if ($separator) {
			return array_merge(array(
				Field::make('html', $id . '_sep')
					->set_html('<label>' . $separator . '</label>')
					->set_classes('seperator ')
			), $buttons);
		} else {
			return $buttons;
		}
	}

	function after_banner_fields()
	{
		$after_banner = carbon_get_theme_option('after_banner');
		$after_banner_container_fields = array();
		foreach ($after_banner as $after_banner_template) {
			$after_banner_container_fields[] = Field::make('checkbox', 'hide_after_header_' . $after_banner_template['template'], 'Hide ' . get_the_title($after_banner_template['template']));
		}
		return $after_banner_container_fields;
	}

	function before_footer_fields()
	{
		$after_banner = carbon_get_theme_option('before_footer');
		$after_banner_container_fields = array();
		foreach ($after_banner as $after_banner_template) {
			$after_banner_container_fields[] = Field::make('checkbox', 'hide_before_footer_' . $after_banner_template['template'], 'Hide ' . get_the_title($after_banner_template['template']));
		}
		return $after_banner_container_fields;
	}
}
class ModulesFields extends GetData
{
	function before_module_fields()
	{
		return  array(
			Field::make('html', 'html_styles')
				->set_html('<label>TITLE AND SECTION ID</label>')
				->set_classes('seperator '),
			Field::make('text', 'title', 'Title')->set_width(33),
			Field::make('text', 'id', 'Section ID')->set_width(33),
			Field::make('checkbox', 'disable_module', 'Disable Module')->set_width(33),
		);
	}

	function module_fields($module_fields)
	{
		return $module_fields;
	}

	function templates_fields()
	{
		return array(
			Field::make('text', 'title', 'Title'),
			Field::make('select', 'template', 'Template')
				->set_options($this->get_posts('templates', 'Select Template')),
		);
	}

	function hero_banner_slider_fields()
	{
		$PostMeta = new PostMeta;
		$button = $PostMeta->_button('hero_banner', 'Button');
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array_merge(
				array(
					Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
					Field::make('complex', 'hero_slider', 'Hero Slider')
						->add_fields(array_merge(
							array(
								Field::make('text', 'heading', 'Heading'),
								Field::make('rich_text', 'description', 'Description'),
								Field::make('image', 'background_image', 'Background Image'),
							),
							$button,
						))
						->set_header_template('<%- heading  %>')
				),
			))
		);
	}

	function featured_product_slider_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array(
				Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
				Field::make('html', 'featured_product_slider')->set_html('<h4> Display Featured Products </h4>'),
				Field::make('text', 'heading', 'Heading'),
			))
		);
	}

	function two_column_image_text_fields()
	{
		$PostMeta = new PostMeta;
		$button_1 = $PostMeta->_button('button_1', 'Button 1');
		$button_2 = $PostMeta->_button('button_2', 'Button 2');

		$buttons = array_merge($button_1, $button_2);

		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array_merge(
				array(
					Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
					Field::make('text', 'heading', 'Heading'),
					Field::make('rich_text', 'description', 'Description'),
					Field::make('image', 'image', 'Image'),
					Field::make('radio', 'image_position', 'Image Position')
						->set_options(array(
							'left' => 'Left',
							'right' => 'Right',
						)),
				),
				$buttons
			))
		);
	}

	function featured_boxes_fields()
	{
		$PostMeta = new PostMeta;
		$button_1 = $PostMeta->_button('button_1', false,);
		$button_2 = $PostMeta->_button('button_2', false);

		$column_1 = array_merge(
			array(
				Field::make('html', 'seperator_1')->set_html('<label>COLUMN 1</label>')->set_classes('seperator '),
				Field::make('text', 'heading_1', 'Heading'),
				Field::make('image', 'background_image_1', 'Background Image'),
			),
			$button_1
		);

		$column_2 = array_merge(
			array(
				Field::make('html', 'seperator_2')->set_html('<label>COLUMN 2</label>')->set_classes('seperator '),
				Field::make('text', 'heading_2', 'Heading'),
				Field::make('image', 'background_image_2', 'Background Image'),
			),
			$button_2
		);

		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array_merge(
				$column_1,
				$column_2
			))
		);
	}
	function newsletter_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array(
				Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
				Field::make('text', 'heading', 'Heading'),
				Field::make('rich_text', 'description', 'Description'),
				Field::make('select', 'contact_form', __('Contact Form 7'))->set_options($this->get_contact_forms())
			))
		);
	}

	function background_image_with_text_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array(
				Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
				Field::make('text', 'heading', 'Heading'),
				Field::make('image', 'background_image', 'Background Image'),
			))
		);
	}
	function wysiwyg_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array(
				Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
				Field::make('rich_text', 'wysiwyg', 'Wysiwyg'),
			))
		);
	}

	function testimonials_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array(
				Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
				Field::make('html', 'featured_product_slider')->set_html('<h4> Display the Customer Testimonials </h4>'),
				Field::make('text', 'heading', 'Heading'),
			))
		);
	}

	function accordion_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array_merge(
				array(
					Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
					Field::make('complex', 'accordion', 'Accordion')
						->add_fields(array(
							Field::make('text', 'accordion_title', 'Accordion Title'),
							Field::make('rich_text', 'accordion_content', 'Accordion Content')
						))
						->set_header_template('<%- accordion_title  %>')
						->set_layout('tabbed-vertical')
				),
			))
		);
	}

	function cta_fields()
	{
		$PostMeta = new PostMeta;
		$button = $PostMeta->_button('cta', 'Button');
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array_merge(
				array(
					Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
					Field::make('text', 'heading', 'Heading'),
					Field::make('rich_text', 'description', 'Description'),
				),
				$button,
			))
		);
	}

	function contact_form_fields()
	{
		return array_merge(
			$this->before_module_fields(),
			$this->module_fields(array(
				Field::make('html', 'seperator_1')->set_html('<label>CONTENTS</label>')->set_classes('seperator '),
				Field::make('rich_text', 'description', 'Description'),
				Field::make('select', 'contact_form', __('Contact Form 7'))->set_options($this->get_contact_forms())
			))
		);
	}
}


/*-----------------------------------------------------------------------------------*/
/* Theme Settings
/*-----------------------------------------------------------------------------------*/
class ThemeOptionsMeta extends PostMeta
{
	function theme_options()
	{
		global $theme_settings;
		$theme_settings_container = Container::make('theme_options', __('Theme Settings'))->set_page_parent('themes.php');
		foreach ($theme_settings as $theme_setting) {
			$theme_settings_container->add_tab($theme_setting['label'], $this->{$theme_setting['id'] . '_fields'}());
		}
		return $theme_settings_container;
	}

	function theme_options_single()
	{
		global $theme_settings;

		foreach ($theme_settings as $theme_setting) {
			$theme_settings_container = Container::make('theme_options', __('→' . $theme_setting['label']))->set_page_parent('themes.php');
			$theme_settings_container->add_fields($this->{$theme_setting['id'] . '_fields'}());
		}
		return $theme_settings_container;
	}

	function general_settings_fields()
	{
		return array(
			Field::make('checkbox', 'disable_gutenberg', 'Disable Gutenberg'),
			Field::make('image', 'placeholder_image', 'Placeholder Image'),
		);
	}
	function brand_details_fields()
	{
		return array(
			Field::make('image', 'logo', 'Logo')->set_width(33),
			Field::make('image', 'alt_logo', 'Alt Logo')->set_width(33),
			Field::make('image', 'footer_logo', 'Footer Logo')->set_width(33),
			Field::make('text', 'phone_number', 'Phone Number'),
			Field::make('text', 'email_address', 'Email Address'),
			Field::make('complex', 'branches', 'Branches')
				->add_fields(array(
					Field::make('text', 'location', 'Location'),
					Field::make('rich_text', 'location_link', 'Location Link'),
					Field::make('rich_text', 'address', 'Address'),
					Field::make('rich_text', 'opening_hours', 'Opening Hours'),
					Field::make('rich_text', 'map', 'Map'),
				))
				->set_layout('tabbed-vertical')
				->set_header_template('<%- location  %>'),
			Field::make('text', 'facebook_url', 'Facebook URL'),
			Field::make('text', 'twitter_url', 'Twitter URL'),
			Field::make('text', 'instagram_url', 'Instagram URL'),
		);
	}

	function after_banner_fields()
	{
		return array(
			Field::make('complex', 'after_banner', 'Template')
				->add_fields(array(
					Field::make('text', 'title', 'Title'),
					Field::make('select', 'template', 'Template')
						->set_options($this->get_posts('templates', 'Select Template')),
				))
				->set_header_template('<%- title  %>')
		);
	}

	function before_footer_fields()
	{
		return array(
			Field::make('complex', 'before_footer', 'Template')
				->add_fields(array(
					Field::make('text', 'title', 'Title'),
					Field::make('select', 'template', 'Template')
						->set_options($this->get_posts('templates', 'Select Template')),
				))
				->set_header_template('<%- title  %>')
		);
	}

	function header_settings_fields()
	{
		return array(
			Field::make('html', 'top_bar_html')
				->set_html('<label>TOP BAR</label>')
				->set_classes('seperator '),
			Field::make('select',  'top_bar_middle_icon', 'Middle Column Icon')
				->set_options(svg_list()),
			Field::make('rich_text', 'top_bar_middle', 'Middle Column Text')
		);
	}

	function footer_settings_fields()
	{
		return array_merge(
			array(
				Field::make('html', 'footer_text_html')
					->set_html('<label>FOOTER TEXT</label>')
					->set_classes('seperator '),
				Field::make('rich_text', 'footer_text', ''),
			),
		);
	}
}

$ThemeOptionsMeta = new ThemeOptionsMeta();

$ThemeOptionsMeta->theme_options();

$ThemeOptionsMeta->theme_options_single();

$PostMeta = new PostMeta();

/*-----------------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------------*/
/* Page Banner
/*-----------------------------------------------------------------------------------*/
Container::make('post_meta', 'Page Banner')
	->where('post_type', '=', 'page')
	->or_where('post_type', '=', 'medicalconditions')
	->set_context('side')
	->add_fields(array_merge(array(
		Field::make('checkbox', 'hide_page_banner', 'Hide Page Banner'),
		Field::make('textarea', 'page_banner_description', 'Page Banner Description'),
		Field::make('select', 'page_banner_style', 'Page Panner Style')
			->set_options(array(
				'style-1' => 'Style 1',
				'style-2' => 'Style 2',
				'style-3' => 'Style 3',
			)),
	), $PostMeta->_button_full_width('banner')));

/*-----------------------------------------------------------------------------------*/
/* Modules
/*-----------------------------------------------------------------------------------*/
$Modules = new Modules();
Container::make('post_meta', 'Modules')
	->where('post_template', '=', 'templates/modules.php')
	->where('post_type', '!=', 'accordions')
	->where('post_type', '!=', 'galleries')
	->or_where('post_type', '=', 'templates')
	->add_fields(array($Modules->modules_post_meta()));



/*-----------------------------------------------------------------------------------*/
/* Testimonial
/*-----------------------------------------------------------------------------------*/
Container::make('post_meta', 'Testimonial Content')
	->where('post_type', '=', 'testimonials')
	->add_fields(array(
		Field::make('text', 'testimonial_title', 'Testimonial Title'),
		Field::make('textarea', 'testimonial_content', 'Testimonial Content'),
	));

/*-----------------------------------------------------------------------------------*/
/* CSS, Header and Footer Scripts
/*-----------------------------------------------------------------------------------*/
Container::make('post_meta', 'Custom CSS / Header Scripts / Footer Scripts')
	->set_priority('default')
	->where('post_type', '=', 'post')
	->or_where('post_type', '=', 'page')
	->or_where('post_type', '=', 'medicalconditions')
	->add_fields(array(
		Field::make('textarea', 'page_custom_css', 'Custom CSS'),
		Field::make('header_scripts', 'page_header_scripts', __('Header Scripts')),
		Field::make('footer_scripts', 'page_footer_scripts', __('Footer Scripts')),
	));


/*-----------------------------------------------------------------------------------*/
/* Documentaton
/*-----------------------------------------------------------------------------------*/
/*Container::make( 'theme_options', __( 'Documentation' ) )
->add_fields(array(
	$PostMeta->_html( 'docx', $PostMeta->_documentation()),
));*/

/*-----------------------------------------------------------------------------------*/
/* Header and Footer Scripts
/*-----------------------------------------------------------------------------------*/
Container::make('theme_options', __('→Header and Footer Scripts'))
	->set_page_parent('themes.php')
	->add_fields(array(
		Field::make('header_scripts', 'header_scripts', __('Header Scripts')),
		Field::make('footer_scripts', 'footer_scripts', __('Footer Scripts'))
	));


/*-----------------------------------------------------------------------------------*/
/* User Custom Field
/*-----------------------------------------------------------------------------------*/
/*Container::make( 'user_meta', 'Custom Field' )
->add_fields( array(
	Field::make( 'checkbox', 'newsletter', "I would like to receive email communications about  product updates, news and offers."),
) );*/

/*-----------------------------------------------------------------------------------*/
/* Products
/*-----------------------------------------------------------------------------------*/
Container::make('post_meta', 'Product Data')
	->where('post_type', '=', 'product')
	->add_tab('PRODUCT INFO',  array(
		Field::make('text', 'product_size', 'Product Size'),
		Field::make('checkbox', 'contains_alcohol', 'Contains Alcohol'),
		Field::make('checkbox', 'for_vegan', 'For Vegan'),

	))
	->add_tab('IN THIS BOX',  array(
		Field::make('association', 'in_this_box', __(''))
			->set_types(array(
				array(
					'type'      => 'post',
					'post_type' => 'chocolates',
				)
			)),
	))
	->add_tab('INGREDIENTS',  array(
		Field::make('rich_text', 'ingredients', '')
	))
	->add_tab('NUTRIIONAL VALUE',  array(
		Field::make('rich_text', 'nutritional_value', '')
	))
	->add_tab('ALLERGENS',  array(
		Field::make('rich_text', 'allergens', '')
	))
	->add_tab('STORAGE',  array(
		Field::make('rich_text', 'storage', '')
	))
	->add_tab('CUSTOM PRODUCT SELECTION',  array(
		Field::make('html', 'product_selection_html')
			->set_html('<h3> Select items only if this product is a custom selection  </h3>'),
		Field::make('text', 'maximum_products', 'Maximum Products')
			->set_help_text('If leave blank defaults to attribute Box Size. Works only on variable products.'),

		Field::make('association', 'product_selection', __(''))
			->set_types(array(
				array(
					'type'      => 'post',
					'post_type' => 'chocolates',
				)
			)),
	));
/*-----------------------------------------------------------------------------------*/
/* Featured Posts
/*-----------------------------------------------------------------------------------*/
Container::make('theme_options', __('Settings'))
	->set_page_parent('edit.php')
	->add_fields(array(
		Field::make('association', 'featured_posts', __('Featured Posts'))
			->set_types(array(
				array(
					'type'      => 'post',
					'post_type' => 'post',
				)
			)),
	));
